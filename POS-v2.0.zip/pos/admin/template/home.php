                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                    </div>
				  <?php 
						$sql=" select * from barang where stok <= 3";
						$row = $config -> prepare($sql);
						$row -> execute();
						$r = $row -> rowCount();
						if($r > 0){
					?>	
					<?php
							echo "
							<div class='alert alert-warning'>
								<span class='glyphicon glyphicon-info-sign'></span> Ada <span style='color:red'>$r</span> barang yang Stok tersisa sudah kurang dari 3 items. silahkan pesan lagi !!
								<span class='pull-right'><a href='index.php?page=barang&stok=yes'>Tabel Barang <i class='fa fa-angle-double-right'></i></a></span>
							</div>
							";	
						}
					?>
				  <?php $hasil_barang = $lihat -> barang_row();?>
				  <?php $hasil_kategori = $lihat -> kategori_row();?>
				  <?php $stok = $lihat -> barang_stok_row();?>
				  <?php $jual = $lihat -> jual_row();?>
                    <!-- Content Row -->
                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body"><a class="text-decoration-none" href='index.php?page=barang'>
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-3" style="font-size:15px;font-weight:700;">
                                                Barang</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800 mb-3"><?php echo number_format($hasil_barang);?></div>

                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                  </a>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body"><a class="text-decoration-none" href='index.php?page=barang'>
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-3" style="font-size:15px;font-weight:700;">
                                                Stok Barang</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800 mb-3"><?php echo number_format($stok['jml']);?></div>

                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                  </a>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body"><a class="text-decoration-none" href='index.php?page=laporan'>
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-3" style="font-size:15px;font-weight:700;">Barang Terjual
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 mb-3 font-weight-bold text-gray-800"><?php echo number_format($jual['stok']);?></div>

									</div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                  </a>
                                </div>
                            </div>
                        </div>

                        <!-- Pending Requests Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body"><a class="text-decoration-none" href='index.php?page=kategori'>
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-3" style="font-size:15px;font-weight:700;">
                                                Kategori Barang</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800 mb-3"><?php echo number_format($hasil_kategori);?></div>

                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-list-alt fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                  </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Page Transaksi -->
                    <div class="d-sm-flex align-items-center justify-content-between mt-4 mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Transaksi</h1>
                    </div>
                                                <div class="row">
                                <div class="col-xl-3 col-md-6 mb-4">
                                    <div class="card text-white shadow border-0" style="background:#1cc88a;">
                                      <a class="text-decoration-none" href='index.php?page=jual'>
                                        <div class="card-body shadow rounded text-white font-weight-bold">
                                              Pos Kasir
                                        </div>
                                      </a>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-md-6 mb-4">
                                    <div class="card text-white shadow border-0" style="background:#36b9cc;">
                                      <a class="text-decoration-none" href='index.php?page=laporan'>
                                        <div class="card-body shadow rounded text-white font-weight-bold">
                                              Laporan Penjualan
                                        </div>
                                      </a>
                                    </div>
                                </div>
                            </div>
                            
